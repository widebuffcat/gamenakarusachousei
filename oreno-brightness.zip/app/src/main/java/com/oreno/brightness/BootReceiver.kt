package com.oreno.brightness

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (Curve.enabled(c) && Settings.System.canWrite(c)) {
            c.startForegroundService(Intent(c, BrightnessService::class.java))
        }
    }
}
