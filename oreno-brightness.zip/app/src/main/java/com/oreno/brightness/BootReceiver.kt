package com.oreno.brightness

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Curve.setNote(c, "boot", "受信 ${i.action}")
        if (Curve.enabled(c) && Settings.System.canWrite(c)) {
            try {
                c.startForegroundService(Intent(c, BrightnessService::class.java))
                Curve.setNote(c, "boot", "受信 ${i.action} → 開始要求OK")
            } catch (e: Exception) {
                Curve.setNote(c, "boot", "開始失敗 ${e.javaClass.simpleName}")
            }
        } else {
            Curve.setNote(c, "boot", "受信したが無効または権限なし")
        }
    }
}
