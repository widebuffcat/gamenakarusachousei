package com.oreno.brightness

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import kotlin.math.abs
import kotlin.math.roundToInt

class BrightnessService : Service(), SensorEventListener {
    private lateinit var sm: SensorManager
    private var sensor: Sensor? = null
    private val handler = Handler(Looper.getMainLooper())
    private var smoothU = -1f
    private var curve: List<Pt> = Curve.defaultCurve()
    private var smooth = false
    private var target = 128
    private var current = -1
    private var moving = false
    private var listening = false

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "active") {
            curve = Curve.active(this)
            recompute(true)
        }
        if (key == "smooth") {
            smooth = Curve.smooth(this)
            recompute(true)
        }
        if (key == "enabled" && !Curve.enabled(this)) stopSelf()
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == Intent.ACTION_SCREEN_ON) startListening() else stopListening()
        }
    }

    private val stepper = object : Runnable {
        override fun run() {
            val diff = target - current
            if (diff == 0) {
                moving = false
                return
            }
            val size = maxOf(1, abs(diff) / 8)
            current += if (diff > 0) minOf(size, diff) else -minOf(size, -diff)
            try {
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, current)
            } catch (e: Exception) {
            }
            handler.postDelayed(this, 40)
        }
    }

    override fun onCreate() {
        super.onCreate()
        Curve.setNote(this, "svc", "サービス開始")
        sm = getSystemService(SENSOR_SERVICE) as SensorManager
        sensor = sm.getDefaultSensor(Sensor.TYPE_LIGHT)
        curve = Curve.active(this)
        smooth = Curve.smooth(this)

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("oreno", "自動調整", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "oreno")
            .setSmallIcon(android.R.drawable.ic_menu_day)
            .setContentTitle("oreno明るさ自動調整")
            .setContentText("画面の明るさを自動調整中")
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(screenReceiver, f, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(screenReceiver, f)
        }
        getSharedPreferences("oreno", MODE_PRIVATE).registerOnSharedPreferenceChangeListener(prefListener)
        if ((getSystemService(POWER_SERVICE) as PowerManager).isInteractive) startListening()
    }

    private fun startListening() {
        if (listening) return
        val s = sensor ?: return
        if (Settings.System.canWrite(this)) {
            try {
                Settings.System.putInt(
                    contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                    Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
                )
            } catch (e: Exception) {
            }
        }
        current = try {
            Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS)
        } catch (e: Exception) {
            128
        }
        smoothU = -1f
        sm.registerListener(this, s, SensorManager.SENSOR_DELAY_NORMAL)
        listening = true
    }

    private fun stopListening() {
        if (!listening) return
        sm.unregisterListener(this)
        handler.removeCallbacks(stepper)
        moving = false
        listening = false
    }

    override fun onSensorChanged(e: SensorEvent) {
        val u = Curve.u(e.values[0])
        smoothU = if (smoothU < 0f) u else smoothU + 0.3f * (u - smoothU)
        recompute(false)
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    private fun recompute(force: Boolean) {
        if (!listening || smoothU < 0f) return
        val pct = Curve.pctAt(curve, Curve.luxFromU(smoothU), smooth)
        target = (pct / 100f * 255f).roundToInt().coerceIn(1, 255)
        if ((force || abs(target - current) >= 2) && !moving) {
            moving = true
            handler.post(stepper)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopListening()
        try {
            unregisterReceiver(screenReceiver)
        } catch (e: Exception) {
        }
        getSharedPreferences("oreno", MODE_PRIVATE).unregisterOnSharedPreferenceChangeListener(prefListener)
        super.onDestroy()
    }
}
