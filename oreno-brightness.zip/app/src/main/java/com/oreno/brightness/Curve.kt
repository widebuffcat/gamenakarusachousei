package com.oreno.brightness

import android.content.Context
import java.util.Locale
import kotlin.math.log10
import kotlin.math.pow

class Pt(var lux: Float, var pct: Float)

object Curve {
    const val SLOTS = 5
    const val MAX_LUX = 30000f

    // AOSP/Pixel系の標準カーブ(0lux≒5nit, 5000lux≒430nit, 10000lux≒520nit)を
    // スライダー位置(%)に換算した目安。中間点は推定値。
    fun defaultCurve(): MutableList<Pt> = mutableListOf(
        Pt(0f, 10f), Pt(1f, 18f), Pt(5f, 28f), Pt(20f, 38f), Pt(100f, 50f),
        Pt(300f, 58f), Pt(1000f, 72f), Pt(3000f, 84f), Pt(5000f, 91f), Pt(10000f, 100f)
    )

    fun u(lux: Float): Float = log10(1f + lux.coerceAtLeast(0f))
    fun luxFromU(u: Float): Float = 10f.pow(u) - 1f

    fun pctAt(pts: List<Pt>, lux: Float): Float {
        if (pts.isEmpty()) return 50f
        if (lux <= pts.first().lux) return pts.first().pct
        if (lux >= pts.last().lux) return pts.last().pct
        for (i in 0 until pts.size - 1) {
            val a = pts[i]
            val b = pts[i + 1]
            if (lux <= b.lux) {
                val ua = u(a.lux)
                val ub = u(b.lux)
                val t = if (ub - ua < 1e-6f) 0f else (u(lux) - ua) / (ub - ua)
                return a.pct + (b.pct - a.pct) * t
            }
        }
        return pts.last().pct
    }

    fun fmtLux(l: Float): String = if (l < 10f) String.format(Locale.US, "%.1f", l) else l.toInt().toString()
    fun fmtPct(p: Float): String = String.format(Locale.US, "%.1f", p)

    fun encode(pts: List<Pt>): String = pts.joinToString(",") { "${it.lux}:${it.pct}" }

    fun decode(s: String?): MutableList<Pt>? {
        if (s.isNullOrBlank()) return null
        return try {
            val l = s.split(",").map {
                val p = it.split(":")
                Pt(p[0].toFloat(), p[1].toFloat())
            }.sortedBy { it.lux }.toMutableList()
            if (l.size < 2) return null
            var m = 0f
            for (p in l) {
                if (p.pct < m) p.pct = m
                m = p.pct
            }
            l
        } catch (e: Exception) {
            null
        }
    }

    private fun p(c: Context) = c.getSharedPreferences("oreno", Context.MODE_PRIVATE)
    fun enabled(c: Context) = p(c).getBoolean("enabled", true)
    fun setEnabled(c: Context, v: Boolean) = p(c).edit().putBoolean("enabled", v).apply()
    fun active(c: Context): MutableList<Pt> = decode(p(c).getString("active", null)) ?: defaultCurve()
    fun saveActive(c: Context, pts: List<Pt>) = p(c).edit().putString("active", encode(pts)).apply()
    fun slot(c: Context, i: Int): MutableList<Pt> = decode(p(c).getString("slot$i", null)) ?: defaultCurve()
    fun saveSlot(c: Context, i: Int, pts: List<Pt>) = p(c).edit().putString("slot$i", encode(pts)).apply()
    fun slotName(c: Context, i: Int): String = p(c).getString("name$i", null) ?: "スロット${i + 1}"
    fun setSlotName(c: Context, i: Int, n: String) = p(c).edit().putString("name$i", n).apply()
    fun selectedSlot(c: Context): Int = p(c).getInt("sel", 0)
    fun setSelectedSlot(c: Context, i: Int) = p(c).edit().putInt("sel", i).apply()
}
