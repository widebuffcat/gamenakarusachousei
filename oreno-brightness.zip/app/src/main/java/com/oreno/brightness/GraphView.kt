package com.oreno.brightness

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration

class GraphView(ctx: Context) : View(ctx) {
    var points: MutableList<Pt> = Curve.defaultCurve()
    var curLux = -1f
    var smoothCurve = false
    var selected: Pt? = null
    var onSelect: ((Pt?) -> Unit)? = null
    var onChanged: (() -> Unit)? = null

    private val d = resources.displayMetrics.density
    private val padL = 54 * d
    private val padR = 16 * d
    private val padT = 18 * d
    private val padB = 42 * d
    private val uMax = Curve.u(Curve.MAX_LUX)
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop

    private val gridP = Paint().apply { color = Color.parseColor("#33FFFFFF"); strokeWidth = d; style = Paint.Style.STROKE }
    private val textP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#CCFFFFFF"); textSize = 11 * d }
    private val lineP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#4FC3F7"); strokeWidth = 3 * d; style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND }
    private val ptP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#4FC3F7"); style = Paint.Style.FILL }
    private val selP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FFC107"); style = Paint.Style.FILL }
    private val ringP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; strokeWidth = 2 * d; style = Paint.Style.STROKE }
    private val curP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FF7043"); strokeWidth = 2 * d; style = Paint.Style.STROKE
        pathEffect = DashPathEffect(floatArrayOf(10 * d, 6 * d), 0f)
    }
    private val labelP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 13 * d; isFakeBoldText = true }

    private var dragging = false
    private var downHit = false
    private var moved = false
    private var offset = 0f
    private var downX = 0f

    private val lp = Runnable {
        val s = selected
        if (s != null && dragging && !moved && downHit && points.size > 2) {
            points.remove(s)
            selected = null
            dragging = false
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            onSelect?.invoke(null)
            onChanged?.invoke()
            invalidate()
        }
    }

    fun replacePoints(l: MutableList<Pt>) {
        points = l
        selected = null
        onSelect?.invoke(null)
        invalidate()
    }

    private fun px(pct: Float) = padL + (width - padL - padR) * pct / 100f
    private fun py(lux: Float): Float =
        (height - padB) - (height - padT - padB) * (Curve.u(lux) / uMax).coerceIn(0f, 1f)

    private fun pctFromX(x: Float) = ((x - padL) / (width - padL - padR) * 100f).coerceIn(0f, 100f)
    private fun luxFromY(y: Float): Float {
        val t = ((height - padB - y) / (height - padT - padB)).coerceIn(0f, 1f)
        return Curve.luxFromU(t * uMax).coerceIn(0f, Curve.MAX_LUX)
    }

    override fun onDraw(c: Canvas) {
        c.drawColor(Color.parseColor("#1E1E1E"))
        val w = width.toFloat()
        val h = height.toFloat()
        textP.textAlign = Paint.Align.CENTER
        for (pct in 0..100 step 25) {
            val x = px(pct.toFloat())
            c.drawLine(x, padT, x, h - padB, gridP)
            c.drawText("$pct%", x, h - padB + 15 * d, textP)
        }
        c.drawText("画面の明るさ (%)", (padL + w - padR) / 2, h - 6 * d, textP)
        textP.textAlign = Paint.Align.RIGHT
        for (lux in floatArrayOf(0f, 1f, 10f, 100f, 1000f, 10000f)) {
            val y = py(lux)
            c.drawLine(padL, y, w - padR, y, gridP)
            c.drawText(lux.toInt().toString(), padL - 6 * d, y + 4 * d, textP)
        }
        textP.textAlign = Paint.Align.LEFT
        c.drawText("照度 (lux)", 4 * d, 12 * d, textP)

        if (curLux >= 0f) {
            val y = py(curLux.coerceAtMost(Curve.MAX_LUX))
            c.drawLine(padL, y, w - padR, y, curP)
        }

        val s = points
        if (s.isEmpty()) return
        val path = Path()
        if (smoothCurve) {
            var y = h - padB
            path.moveTo(px(Curve.pctAt(s, 0f, true)), y)
            while (y > padT) {
                y = maxOf(y - 3 * d, padT)
                path.lineTo(px(Curve.pctAt(s, luxFromY(y), true)), y)
            }
        } else {
            path.moveTo(px(s[0].pct), h - padB)
            for (p in s) path.lineTo(px(p.pct), py(p.lux))
            path.lineTo(px(s.last().pct), padT)
        }
        c.drawPath(path, lineP)

        for (p in s) {
            val x = px(p.pct)
            val y = py(p.lux)
            if (p === selected) {
                c.drawCircle(x, y, 11 * d, selP)
                c.drawCircle(x, y, 11 * d, ringP)
            } else {
                c.drawCircle(x, y, 7 * d, ptP)
            }
        }
        val sel = selected
        if (sel != null) {
            val x = px(sel.pct)
            val y = py(sel.lux)
            val label = "${Curve.fmtLux(sel.lux)} lux / ${Curve.fmtPct(sel.pct)}%"
            if (x > w * 0.55f) {
                labelP.textAlign = Paint.Align.RIGHT
                c.drawText(label, x - 16 * d, y - 12 * d, labelP)
            } else {
                labelP.textAlign = Paint.Align.LEFT
                c.drawText(label, x + 16 * d, y - 12 * d, labelP)
            }
        }
    }

    private fun dist(x1: Float, y1: Float, x2: Float, y2: Float): Double =
        Math.hypot((x1 - x2).toDouble(), (y1 - y2).toDouble())

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                moved = false
                val hit = points.minByOrNull { dist(e.x, e.y, px(it.pct), py(it.lux)) }
                val near = hit != null && dist(e.x, e.y, px(hit.pct), py(hit.lux)) < 32 * d
                downHit = near
                val s: Pt = if (near) {
                    hit!!
                } else {
                    val lux = luxFromY(e.y)
                    val np = Pt(lux, Curve.pctAt(points, lux, smoothCurve))
                    points.add(np)
                    points.sortBy { it.lux }
                    np
                }
                selected = s
                dragging = true
                offset = e.x - px(s.pct)
                downX = e.x
                onSelect?.invoke(s)
                if (near) postDelayed(lp, 600)
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val s = selected
                if (!dragging || s == null) return true
                if (Math.abs(e.x - downX) > slop) {
                    moved = true
                    removeCallbacks(lp)
                }
                val i = points.indexOf(s)
                val lo = if (i > 0) points[i - 1].pct else 0f
                val hi = if (i < points.size - 1) points[i + 1].pct else 100f
                s.pct = pctFromX(e.x - offset).coerceIn(lo, hi)
                onSelect?.invoke(s)
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(lp)
                if (dragging) {
                    dragging = false
                    onChanged?.invoke()
                }
                return true
            }
        }
        return true
    }
}
