package com.oreno.brightness

import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings

class KeepAliveJob : JobService() {
    override fun onStartJob(p: JobParameters?): Boolean {
        Curve.setNote(this, "job", "ジョブ実行")
        if (Curve.enabled(this) && Settings.System.canWrite(this)) {
            try {
                startForegroundService(Intent(this, BrightnessService::class.java))
            } catch (e: Exception) {
                Curve.setNote(this, "job", "ジョブ失敗 ${e.javaClass.simpleName}")
            }
        }
        return false
    }

    override fun onStopJob(p: JobParameters?): Boolean = true

    companion object {
        fun schedule(c: Context) {
            val js = c.getSystemService(JobScheduler::class.java)
            if (js.getPendingJob(1) != null) return
            js.schedule(
                JobInfo.Builder(1, ComponentName(c, KeepAliveJob::class.java))
                    .setPeriodic(15 * 60 * 1000L)
                    .setPersisted(true)
                    .build()
            )
        }
    }
}
