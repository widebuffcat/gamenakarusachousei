package com.oreno.brightness

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity(), SensorEventListener {
    private lateinit var graph: GraphView
    private lateinit var readout: TextView
    private lateinit var status: TextView
    private lateinit var permBox: LinearLayout
    private lateinit var sm: SensorManager
    private val slotBtns = ArrayList<Button>()
    private val hint = "グラフの点をタッチして横にドラッグ。線の上の何もない所をタッチすると点を追加、点の長押しで削除。"

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        sm = getSystemService(SENSOR_SERVICE) as SensorManager

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        setContentView(ScrollView(this).apply { addView(root) })

        root.addView(TextView(this).apply { text = "oreno明るさ自動調整"; textSize = 20f })
        status = TextView(this).apply { text = "照度センサー待機中…"; textSize = 14f }
        root.addView(status)
        readout = TextView(this).apply { text = hint; textSize = 15f; minLines = 3 }
        root.addView(readout)

        graph = GraphView(this)
        graph.points = Curve.active(this)
        graph.smoothCurve = Curve.smooth(this)
        graph.onSelect = { p ->
            readout.text = if (p == null) hint else
                "選択中の点\n照度 ${Curve.fmtLux(p.lux)} lux / 画面の明るさ ${Curve.fmtPct(p.pct)}% (レベル ${(p.pct / 100f * 255f).toInt().coerceIn(1, 255)}/255)"
        }
        graph.onChanged = { Curve.saveActive(this, graph.points) }
        root.addView(graph, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(400)))

        root.addView(TextView(this).apply { text = "保存スロット（長押しで名前変更）"; textSize = 13f; setPadding(0, dp(10), 0, 0) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (i in 0 until Curve.SLOTS) {
            val btn = Button(this).apply {
                isAllCaps = false
                textSize = 11f
                maxLines = 1
                minWidth = 0
                minimumWidth = 0
                setPadding(dp(2), 0, dp(2), 0)
                setOnClickListener {
                    Curve.setSelectedSlot(this@MainActivity, i)
                    val pts = Curve.slot(this@MainActivity, i)
                    graph.replacePoints(pts)
                    Curve.saveActive(this@MainActivity, pts)
                    refreshSlots()
                }
                setOnLongClickListener { rename(i); true }
            }
            slotBtns.add(btn)
            row.addView(btn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        root.addView(row)

        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(Button(this).apply {
            text = "選択中のスロットに保存"
            isAllCaps = false
            setOnClickListener {
                val i = Curve.selectedSlot(this@MainActivity)
                Curve.saveSlot(this@MainActivity, i, graph.points)
                Toast.makeText(this@MainActivity, "${Curve.slotName(this@MainActivity, i)}に保存しました", Toast.LENGTH_SHORT).show()
            }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row2.addView(Button(this).apply {
            text = "初期値に戻す"
            isAllCaps = false
            setOnClickListener {
                val pts = Curve.defaultCurve()
                graph.replacePoints(pts)
                Curve.saveActive(this@MainActivity, pts)
            }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(row2)

        root.addView(Switch(this).apply {
            text = "曲線を滑らかにする"
            isChecked = Curve.smooth(this@MainActivity)
            setPadding(0, dp(10), 0, 0)
            setOnCheckedChangeListener { _, on ->
                Curve.setSmooth(this@MainActivity, on)
                graph.smoothCurve = on
                graph.invalidate()
            }
        })

        root.addView(Switch(this).apply {
            text = "自動調整を有効にする"
            isChecked = Curve.enabled(this@MainActivity)
            setPadding(0, dp(10), 0, dp(10))
            setOnCheckedChangeListener { _, on ->
                Curve.setEnabled(this@MainActivity, on)
                if (on && Settings.System.canWrite(this@MainActivity)) {
                    this@MainActivity.startForegroundService(Intent(this@MainActivity, BrightnessService::class.java))
                }
            }
        })

        root.addView(TextView(this).apply { text = "必要な許可"; textSize = 13f })
        permBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(permBox)

        refreshSlots()
    }

    private fun refreshSlots() {
        val sel = Curve.selectedSlot(this)
        for (i in 0 until Curve.SLOTS) {
            slotBtns[i].text = Curve.slotName(this, i)
            slotBtns[i].alpha = if (i == sel) 1f else 0.45f
        }
    }

    private fun rename(i: Int) {
        val et = EditText(this)
        et.setText(Curve.slotName(this, i))
        et.setSelection(et.text.length)
        AlertDialog.Builder(this).setTitle("名前を変更").setView(et)
            .setPositiveButton("OK") { _, _ ->
                val t = et.text.toString().trim()
                if (t.isNotEmpty()) {
                    Curve.setSlotName(this, i, t)
                    refreshSlots()
                }
            }
            .setNegativeButton("キャンセル", null).show()
    }

    private fun addPerm(label: String, ok: Boolean, action: () -> Unit) {
        permBox.addView(Button(this).apply {
            text = (if (ok) "✓ " else "") + label
            isAllCaps = false
            setOnClickListener { action() }
        })
    }

    private fun refreshPerms() {
        permBox.removeAllViews()
        addPerm("システム設定の変更を許可", Settings.System.canWrite(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        }
        if (Build.VERSION.SDK_INT >= 33) {
            val ok = checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            addPerm("通知を許可", ok) { requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1) }
        }
        val ign = getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)
        addPerm("電池の最適化から除外", ign) {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }
        addPerm("自動起動を許可（アプリ情報を開く）", false) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
    }

    override fun onResume() {
        super.onResume()
        refreshPerms()
        if (Curve.enabled(this) && Settings.System.canWrite(this)) {
            startForegroundService(Intent(this, BrightnessService::class.java))
        }
        sm.getDefaultSensor(Sensor.TYPE_LIGHT)?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL) }
    }

    override fun onPause() {
        super.onPause()
        sm.unregisterListener(this)
    }

    override fun onSensorChanged(e: SensorEvent) {
        val lux = e.values[0]
        graph.curLux = lux
        graph.invalidate()
        status.text = "現在の照度 ${Curve.fmtLux(lux)} lux → 画面の明るさ ${Curve.fmtPct(Curve.pctAt(graph.points, lux, graph.smoothCurve))}%"
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
}
